﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Text.RegularExpressions;

namespace Test_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(radioButton1.Checked)
            {
                StreamWriter createnewfile = new StreamWriter(@textBox1.Text);
                createnewfile.Close();
                StreamReader readfile = new StreamReader(@textBox1.Text);
                richTextBox1.Clear();
                while (readfile.EndOfStream != true)
                {
                    richTextBox1.Text += readfile.ReadLine() + "\n";
                }
                readfile.Close();
            }

            else if(radioButton2.Checked)
            {
                OpenFileDialog openfile = new OpenFileDialog();
                openfile.InitialDirectory = @"E:\Study\ITD\Sem 2\PROG - 1815\Tests\Test_1\Files";

                if (openfile.ShowDialog() == DialogResult.OK)
                {
                    textBox1.Text = openfile.FileName;
                }

                StreamReader readfile = new StreamReader(@textBox1.Text);
                richTextBox1.Clear();
                while (readfile.EndOfStream != true)
                {
                    richTextBox1.Text += readfile.ReadLine() + "\n";
                }
                readfile.Close();
            }

            else
            {
                MessageBox.Show("Please select if you have to create a new file or open an existing file");
            }

            
        }

        private void button2_Click(object sender, EventArgs e)
        {

            Regex validation = new Regex(@"\d{3}");

            if(validation.IsMatch(textBox2.Text))
            {
                StreamWriter writefile = new StreamWriter(@textBox1.Text, append: true);
                writefile.WriteLine(textBox2.Text + "     " + textBox3.Text + "     " + textBox4.Text + "     " + textBox5.Text + "     " + textBox6.Text + "     " + textBox7.Text + "     " + textBox8.Text);
                writefile.Close();
            }
            
            else
            {
                MessageBox.Show("The transaction number should be a three digit number");
            }

            StreamReader readfile = new StreamReader(@textBox1.Text);
            richTextBox1.Clear();
            while (readfile.EndOfStream != true)
            {
                richTextBox1.Text += readfile.ReadLine() + "\n";
            }
            readfile.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
